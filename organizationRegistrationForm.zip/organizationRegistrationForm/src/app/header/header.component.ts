import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  providers: [NgxSpinnerService]
})
export class HeaderComponent implements OnInit {

  	constructor( private router:Router,private SpinnerService: NgxSpinnerService) {}

  	ngOnInit(): void {
  		this.SpinnerService.show(); 
  		setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 900);
	
  	}
  	title = 'registrationForm';

	personalDetails() {
		var personal = document.getElementsByClassName('personal');
		var number = document.getElementsByClassName('number');
		personal[0].classList.add('active');
		number[0].classList.add('active');
		

		var company = document.getElementsByClassName('company');
		var email = document.getElementsByClassName('email');
		var number = document.getElementsByClassName('number');
		if(company[0].classList.contains('active')) {
			company[0].classList.remove('active');
			number[1].classList.remove('active');
		}
		if(email[0].classList.contains('active')) {
			email[0].classList.remove('active');
			number[2].classList.remove('active');
		}

        this.router.navigateByUrl('/personal');
	} 
	companyDetails() {
		var personal = document.getElementsByClassName('personal');
		var email = document.getElementsByClassName('email');
		var number = document.getElementsByClassName('number');
		if(personal[0].classList.contains('active')) {
			personal[0].classList.remove('active');
			number[0].classList.remove('active');
		}

		if(email[0].classList.contains('active')) {
			email[0].classList.remove('active');
			number[2].classList.remove('active');
		}

		var company = document.getElementsByClassName('company');
		var number = document.getElementsByClassName('number');
		company[0].classList.add('active');
		number[1].classList.add('active');

        this.router.navigateByUrl('/company');
        //alert();
	}
	email() {
		var personal = document.getElementsByClassName('personal');
		var company = document.getElementsByClassName('company');
		var number = document.getElementsByClassName('number');
		if(personal[0].classList.contains('active')) {
			personal[0].classList.remove('active');
			number[0].classList.remove('active');
		}
		
		if(company[0].classList.contains('active')) {
			company[0].classList.remove('active');
			number[1].classList.remove('active');
		}

		var email = document.getElementsByClassName('email');
		var number = document.getElementsByClassName('number');
		email[0].classList.add('active');
		number[2].classList.add('active');

        this.router.navigateByUrl('/email');
	}

}
