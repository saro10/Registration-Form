import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
	fullName = "";
	gender = "";
	country = "";
	state = "";
	phone = "";
	img = "";
	companyName = "";
	job="";
	category = "";
	email = "";
	experience = "";
	terms = '';
  	constructor(private SpinnerService: NgxSpinnerService) { }

  	ngOnInit(): void {
  		setTimeout(() => { 
	  			this.SpinnerService.hide(); 
	  	}, 900);
  		var header = document.getElementsByClassName('header');
  		if(header[0].classList.contains('header')) {
  			header[0].classList.add('headerPane');
  		}
  		var registrationForm = document.getElementsByClassName('registrationForm');
  		if(registrationForm[0].classList.contains('registrationForm')) {
  			registrationForm[0].classList.add('dashboard');
  		}
  		
  		this.fullName = localStorage.getItem('fullName');
        this.gender = localStorage.getItem('gender');
        this.country = localStorage.getItem('country');
        this.state = localStorage.getItem('state');
        this.phone = localStorage.getItem('mobileNumber');
        this.companyName =localStorage.getItem('companyName');
        this.job = localStorage.getItem('jobTitle');
        this.category = localStorage.getItem('category');
        this.email = localStorage.getItem('email');
        this.terms = localStorage.getItem('acceptTerms');
        this.experience = localStorage.getItem('experience');
        this.img = localStorage.getItem('image');
  	}
}
