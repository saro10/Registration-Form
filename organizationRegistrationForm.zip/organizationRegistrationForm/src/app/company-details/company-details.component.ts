import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.css']
})
export class CompanyDetailsComponent implements OnInit {
    companyName = "";
    job="";
    exp="";
    cat = "";
    accept = '';
    email= "";
	registerForm: FormGroup;
    submitted = false;
    url : string = "assets/upload.png" as string;
    categories: any = ['Development','Testing','FullStack'];

    constructor(private formBuilder: FormBuilder, private router: Router,private SpinnerService: NgxSpinnerService) { }

    ngOnInit() {
    	setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 900);
        this.registerForm = this.formBuilder.group({
            companyName: ['', Validators.required],
            experience: ['', Validators.required],
            jobTitle: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            category: ['', [Validators.required]],
            acceptTerms : ['', [Validators.required]]
        });
    }

    ngAfterViewInit(): void {
        this.companyName = localStorage.getItem('companyName');
        this.job = localStorage.getItem('jobTitle');
        this.exp = localStorage.getItem('experience');
        //this.url = localStorage.getItem('image');
        this.accept = localStorage.getItem('acceptTerms');
        this.email = localStorage.getItem('email');
    }

    onSelectFile(event) {
	    if (event.target.files && event.target.files[0]) {
	      	var reader = new FileReader();
	      	reader.readAsDataURL(event.target.files[0]);
	      	reader.onload = (event) => {
	        	this.url = reader.result as string;
	      	}
	    }
	}

    get formControlMethod() { 
    	return this.registerForm.controls; 
    }

    onSubmit() {
        this.submitted = true;
        this.SpinnerService.show(); 
        if (this.registerForm.invalid) {
        	setTimeout(() => { 
	  			this.SpinnerService.hide(); 
	  		}, 900);
            return;
        } else {
        	this.submitted = false;
        	let companyDatas = this.registerForm.value;

        	var correctIcon = document.getElementsByClassName('correctIcon');
        	if(correctIcon[1].classList.contains('displayShow')) {
				correctIcon[1].classList.remove('displayShow');
			}

        	var company = document.getElementsByClassName('company');
			var number = document.getElementsByClassName('number');
			if(company[0].classList.contains('active')) {
				company[0].classList.remove('active');
				number[1].classList.remove('active');
				number[1].classList.add('displayShow');
			}

			var email = document.getElementsByClassName('email');
			var number = document.getElementsByClassName('number');
			email[0].classList.add('active');
			number[2].classList.add('active');

        	//Assiging form values to the local Storage
        	localStorage.setItem('companyName',companyDatas.companyName);
        	localStorage.setItem('jobTitle',companyDatas.jobTitle);
        	localStorage.setItem('category',companyDatas.category);
        	localStorage.setItem('email',companyDatas.email);
        	localStorage.setItem('acceptTerms',companyDatas.acceptTerms);
        	localStorage.setItem('experience',companyDatas.experience);
        	localStorage.setItem('image',this.url);
        	
        	setTimeout(() => { 
	  			this.SpinnerService.hide(); 
	  		}, 900);

        	//Navigating to the next step of company detail
        	this.router.navigateByUrl('/email');
        }
    }
    personalPage() {
	  	this.SpinnerService.show(); 
    	var correctIcon = document.getElementsByClassName('correctIcon');
		correctIcon[0].classList.add('displayShow');

    	var personal = document.getElementsByClassName('personal');
		var number = document.getElementsByClassName('number');
		personal[0].classList.add('active');
		number[0].classList.add('active');

		var company = document.getElementsByClassName('company');
		var number = document.getElementsByClassName('number');
		if(company[0].classList.contains('active')) {
			company[0].classList.remove('active');
			number[1].classList.remove('active');
			number[0].classList.remove('displayShow');
		}
		setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 1000);
    	this.router.navigateByUrl('/personal');
    }
}
