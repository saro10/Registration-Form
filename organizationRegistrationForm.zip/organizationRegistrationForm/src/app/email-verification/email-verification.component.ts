import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-email-verification',
  templateUrl: './email-verification.component.html',
  styleUrls: ['./email-verification.component.css']
})
export class EmailVerificationComponent implements OnInit {
    phone = "";
  	otp: string; 
    timeLeft: number = 30;
    interval;
  	showOtpComponent = true;
  	validateOTP : string = '12345';
  	isValid = false;
    iscounter = false;
  	@ViewChild('ngOtpInput') ngOtpInput: any;

  	constructor(private router: Router,private SpinnerService: NgxSpinnerService) { }

  	ngOnInit(): void {
      this.startTimer();
  	}

    ngAfterViewInit(): void {
        this.phone = localStorage.getItem('mobileNumber');
    }
    startTimer() {
    this.interval = setInterval(() => {
      if(this.timeLeft > 0) {
        this.timeLeft--;
        if(this.timeLeft == 0) {
          alert('Timeout exceeded you cannot verify your account');
          clearTimeout(this.interval);
          this.iscounter = true;
          var verifyAll = document.getElementsByClassName('btn-primary');
          if(verifyAll[0].classList.contains('verifyAll')) {
            verifyAll[0].classList.add('verifyAll');
          } 
        }
      } else {
        this.timeLeft = 30;
      }
    },1000)
  }
  	config = {
	    allowNumbersOnly: false,
	    length: 5,
	    isPasswordInput: false,
	    disableAutoFocus: false,
	    placeholder:'',
	    inputStyles: {
	      'width': '50px',
	      'height': '50px'
	    }
  	};
  	onOtpChange(otp) {
    	var verifyAll = document.getElementsByClassName('btn-primary');
    	this.otp = otp;
    	if(this.otp == this.validateOTP && !this.iscounter) {
    		this.isValid = false;
    		if(verifyAll[0].classList.contains('verifyAll')) {
    			verifyAll[0].classList.remove('verifyAll');
    		} 
    	} else {
    		verifyAll[0].classList.add('verifyAll');
    		this.isValid = true;
    	}
  	}

  	setVal(val) {
    	this.ngOtpInput.setValue(val);
  	}

  	onConfigChange() {
    	this.showOtpComponent = false;
    	this.otp = null;
    	setTimeout(() => {
      		this.showOtpComponent = true;
    	}, 0);
  	}
  	companyPage() {
  		this.SpinnerService.show(); 
  		var correctIcon = document.getElementsByClassName('correctIcon');
		correctIcon[1].classList.add('displayShow');

  		var company = document.getElementsByClassName('company');
		var number = document.getElementsByClassName('number');
		company[0].classList.add('active');
		number[1].classList.add('active');

		var email = document.getElementsByClassName('email');
		var number = document.getElementsByClassName('number');
		if(email[0].classList.contains('active')) {
			email[0].classList.remove('active');
			number[2].classList.remove('active');
			number[1].classList.remove('displayShow');
		}
		setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 1000);
    	this.router.navigateByUrl('/company');
  	}
  	dashboardPage() {
      clearTimeout(this.interval);
	  	this.SpinnerService.show(); 
  		this.router.navigateByUrl('/dashboard');
  	}
}
