import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 

import { GlobalService } from '../common/global.service';

@Component({
  selector: 'app-personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.css']
})
export class PersonalDetailsComponent implements OnInit {
    url : string = "assets/download.png" as string;
    countryList: Array<any>;
    cities: Array<any>;

  	registerFormPersonal: FormGroup;
    submitted = false;

    constructor(private formBuilder: FormBuilder, private router: Router,private SpinnerService: NgxSpinnerService, public global:GlobalService) { }

    ngOnInit() {
    	setTimeout(() => { 
	  		this.SpinnerService.hide(); 
	  	}, 1000);
        this.registerFormPersonal = this.formBuilder.group({
            fullName: ['', Validators.required],
            gender: ['male', Validators.required],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            mobileNumber: [null, [Validators.required, Validators.pattern('[6-9]\\d{9}')]]
        });
        this.countryList = this.global.getCountriesList();
    }

    changeCountry(count) {
        this.cities = this.countryList.find(con => con.name == count).cities;
    }

    //convenience getter for easy access to form fields
    get personalMethod() { 
    	return this.registerFormPersonal.controls; 
    }

    onSubmitPersonalDetails() {
  		this.SpinnerService.show(); 
        this.submitted = true;
        
		if (this.registerFormPersonal.invalid) {
			setTimeout(() => { 
	  			this.SpinnerService.hide(); 
	  		}, 1000);
            return;
    } else {
        	this.submitted = false;
          this.global.isPersonalVisible = false;
          this.global.isCompanyForm = true;
        	let personalDatas = this.registerFormPersonal.value;

          //Assiging form values to the global service to disaplay in dashboard

        	this.global.fullName = personalDatas.fullName
        	this.global.gender = personalDatas.gender
        	this.global.country = personalDatas.country
        	this.global.state = personalDatas.state
        	this.global.phone = personalDatas.mobileNumber

        	//Retaining Form Values
        	this.fullName = personalDatas.fullName;

        	setTimeout(() => { 
  	  			this.SpinnerService.hide(); 
  	  		}, 900);

        	//Navigating to the next step of company details
          this.router.navigateByUrl('/company');
        }
    }
}
