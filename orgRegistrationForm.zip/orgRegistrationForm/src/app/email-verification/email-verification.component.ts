import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 
import { GlobalService } from '../common/global.service';

@Component({
  selector: 'app-email-verification',
  templateUrl: './email-verification.component.html',
  styleUrls: ['./email-verification.component.css']
})
export class EmailVerificationComponent implements OnInit {
    phone = "";
  	otp: string; 
    timeLeft: number = 30;
    interval;
  	showOtpComponent = true;
  	validateOTP : string = '12345';
  	isValid = false;
    iscounter = false;

  	@ViewChild('ngOtpInput') ngOtpInput: any;

  	constructor(private router: Router,private SpinnerService: NgxSpinnerService, 
    public global:GlobalService) { }

  	ngOnInit(): void {
      this.startTimer();
  	}

    ngAfterViewInit(): void {
        this.phone = localStorage.getItem('mobileNumber');
    }
    startTimer() {
    this.interval = setInterval(() => {
      if(this.timeLeft > 0) {
        this.timeLeft--;
        if(this.timeLeft == 0) {
          alert('Timeout exceeded you cannot verify your account');
          clearTimeout(this.interval);
          this.iscounter = true;
          this.global.isVerify = true;
        }
      } else {
        this.timeLeft = 30;
      }
    },1000)
  }
  	config = {
	    allowNumbersOnly: false,
	    length: 5,
	    isPasswordInput: false,
	    disableAutoFocus: false,
	    placeholder:'',
	    inputStyles: {
	      'width': '50px',
	      'height': '50px'
	    }
  	};
  	onOtpChange(otp) {
    	this.otp = otp;
    	if(this.otp == this.validateOTP && !this.iscounter) {
    		this.isValid = false;
    		this.global.isVerify = false;
    	} else {
    		this.global.isVerify = true;
    		this.isValid = true;
    	}
  	}

  	setVal(val) {
    	this.ngOtpInput.setValue(val);
  	}

  	onConfigChange() {
    	this.showOtpComponent = false;
    	this.otp = null;
    	setTimeout(() => {
      		this.showOtpComponent = true;
    	}, 0);
  	}

  	companyPage() {
  		this.SpinnerService.show(); 
  		setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 1000);
      clearTimeout(this.interval);
      this.global.isEmailForm = false;
      this.global.isEmailVisible = true;
      this.global.isCompanyVisible = true;      
    	this.router.navigateByUrl('/company');
  	}

  	dashboardPage() {
      this.global.isEmailVisible = false;
      clearTimeout(this.interval);
	  	this.SpinnerService.show(); 
  		this.router.navigateByUrl('/dashboard');
  	}
}
