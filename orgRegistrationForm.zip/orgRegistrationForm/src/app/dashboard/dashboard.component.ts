import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner"; 
import { GlobalService } from '../common/global.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  	constructor(private SpinnerService: NgxSpinnerService,public global:GlobalService) { }

  	ngOnInit(): void {
      this.global.isHeaderPane = true;
      this.global.isDashRegForm = true;
  		setTimeout(() => { 
	  			this.SpinnerService.hide();
	  	}, 900);
  	}
}
