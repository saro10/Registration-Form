import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 

import { GlobalService } from '../common/global.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  providers: [NgxSpinnerService]
})
export class HeaderComponent implements OnInit {

  	constructor( private router:Router,private SpinnerService: NgxSpinnerService, public global:GlobalService) {}

  	ngOnInit(): void {
  		this.SpinnerService.show(); 
  		setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 900);
	
  	}
  	title = 'registrationForm';

	personalDetails() {
        this.router.navigateByUrl('/personal');
	} 
	companyDetails() {
        this.router.navigateByUrl('/company');
	}
	email() {
        this.router.navigateByUrl('/email');
	}

}
