import { Component } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner"; 


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	constructor( private SpinnerService: NgxSpinnerService) {}
	 ngOnInit(): void {
    	localStorage.setItem('fullName','');
    	localStorage.setItem('gender','');
    	localStorage.setItem('country','');
    	localStorage.setItem('state','');
    	localStorage.setItem('mobileNumber','');
    	localStorage.setItem('companyName','');
    	localStorage.setItem('jobTitle','');
    	localStorage.setItem('category','');
    	localStorage.setItem('email','');
    	localStorage.setItem('acceptTerms','');
    	localStorage.setItem('experience','');
    	localStorage.setItem('image','');
	}
	
}
