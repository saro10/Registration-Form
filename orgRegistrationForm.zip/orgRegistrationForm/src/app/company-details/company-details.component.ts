import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 
import { GlobalService } from '../common/global.service';

@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.css']
})
export class CompanyDetailsComponent implements OnInit {
	registerForm: FormGroup;
    submitted = false;
    url : string = "assets/upload.png" as string;
    categories: any = ['Development','Testing','FullStack'];

    constructor(private formBuilder: FormBuilder, private router: Router,private SpinnerService: NgxSpinnerService, public global:GlobalService) { }

    ngOnInit() {
    	setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 900);
        this.registerForm = this.formBuilder.group({
            companyName: ['', Validators.required],
            experience: ['', Validators.required],
            jobTitle: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            category: ['', [Validators.required]],
            acceptTerms : ['', [Validators.required]]
        });
    }

    onSelectFile(event) {
	    if (event.target.files && event.target.files[0]) {
	      	var reader = new FileReader();
	      	reader.readAsDataURL(event.target.files[0]);
	      	reader.onload = (event) => {
	        	this.url = reader.result as string;
	      	}
	    }
	}

    get formControlMethod() { 
    	return this.registerForm.controls; 
    }

    onSubmit() {
        this.submitted = true;
        this.SpinnerService.show(); 
        if (this.registerForm.invalid) {
        	setTimeout(() => { 
	  			this.SpinnerService.hide(); 
	  		}, 900);
            return;
        } else {
        	this.submitted = false;
        	let companyDatas = this.registerForm.value;
            this.global.isCompanyVisible = false;
            this.global.isEmailForm = true;

        	//Assiging form values to the local Storage
        	this.global.companyName = companyDatas.companyName;
        	this.global.jobTitle = companyDatas.jobTitle;
        	this.global.category = companyDatas.category;
        	this.global.email = companyDatas.email;
        	this.global.acceptTerms = companyDatas.acceptTerms;
        	this.global.experience = companyDatas.experience;
        	this.global.image = this.url;
        	
        	setTimeout(() => { 
	  			this.SpinnerService.hide(); 
	  		}, 900);

        	//Navigating to the next step of company detail
        	this.router.navigateByUrl('/email');
        }
    }
    personalPage() {
	  	this.SpinnerService.show(); 
    	setTimeout(() => { 
  			this.SpinnerService.hide(); 
  		}, 1000);
        this.global.isCompanyForm = false;
        this.global.isPersonalVisible = true;        
    	this.router.navigateByUrl('/personal');
    }
}
